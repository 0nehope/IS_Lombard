﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class AddCategory : Page
    {
        Entities s = new Entities();
        public AddCategory()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            CategoryList.Height = 583;
            if(save_role.idrole!=1)
            {
                AdminBT.Visibility = Visibility.Hidden;
                NameCategory.IsEnabled = false;
                MinPrice.IsEnabled = false;
            }
            AdminBT.Margin=new Thickness (510,150,0,93);
            foreach (var x in s.Виды_товаров)
            {
                CategoryList.Items.Add(x);
            }
        }

        private void CategoryList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(CategoryList.SelectedItem is Виды_товаров selected)
            {
                if (save_role.idrole != 1)
                {
                    NameCategory.Text = selected.Наименование.Trim();
                    MinPrice.Text = Convert.ToInt32(selected.МинЦена).ToString() + "₽";
                }
                else
                {
                    NameCategory.Text = selected.Наименование.Trim();
                    MinPrice.Text = Convert.ToInt32(selected.МинЦена).ToString();
                }
            }
        }

        private void Add_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            CategoryList.SelectedIndex = -1;
            NameCategory.Text = "";
            MinPrice.Text = "";
        }

        private void Save_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (NameCategory.Text != "" || MinPrice.Text != "")
            {
                if (CategoryList.SelectedItem==null)
                {
                MessageBoxResult result = MessageBox.Show("Вы уверены что хотите создать категорию?", "Обновление", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if(MessageBoxResult.Yes==result)
                    {
                        Виды_товаров new_category = new Виды_товаров
                        {
                            Наименование = NameCategory.Text.Trim(),
                            МинЦена = Convert.ToDecimal(MinPrice.Text.Trim()),
                        };
                        bool flag = false;                      
                        foreach (var x in s.Виды_товаров)
                        {
                            if (x.Наименование.ToLower().Trim()==new_category.Наименование.ToLower().Trim())
                            {
                                flag = true;
                                break;
                            }
                        }
                        if(flag==false)
                        {
                            s.Виды_товаров.Add(new_category);
                            s.SaveChanges();
                            //Очистка
                            CategoryList.SelectedIndex = -1;
                            NameCategory.Text = "";
                            MinPrice.Text = "";
                            CategoryList.Items.Clear();
                            foreach (var x in s.Виды_товаров)
                            {
                                CategoryList.Items.Add(x);
                            }
                            MessageBox.Show("Категория добавлена", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        if(flag==true)
                        {
                            MessageBox.Show("Такая категория уже существует", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
                else
                {
                    MessageBoxResult result = MessageBox.Show("Вы уверены что хотите изменить категорию?", "Обновление", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (MessageBoxResult.Yes == result)
                    {
                        var selected = CategoryList.SelectedItem as Виды_товаров;
                        var id_list = CategoryList.SelectedIndex;
                        selected.Наименование = NameCategory.Text.Trim();
                        selected.МинЦена = Convert.ToDecimal(MinPrice.Text.Trim());
                        Виды_товаров EditCategory = selected;
                        bool flag = false;
                        if (selected.Наименование.Trim() != EditCategory.Наименование)//Проверка что наименование остаётся без изменений
                        {
                            foreach (var x in s.Виды_товаров)
                            {
                                if (x.Наименование.ToLower().Trim() == selected.Наименование.ToLower().Trim())//Проверка на существование такого наименования 
                                {
                                    flag = true;
                                    break;
                                }
                            }
                        }
                        if (flag == false)
                        {
                            s.SaveChanges();
                            MessageBox.Show("Категория изменена", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                            CategoryList.Items.Clear();
                            foreach (var x in s.Виды_товаров)
                            {
                                CategoryList.Items.Add(x);
                            }
                            CategoryList.SelectedIndex = id_list;
                        }
                        if(flag==true)
                        {
                            MessageBox.Show("Такая категория уже существует", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            else
                MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void MinPrice_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Delete_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (CategoryList.SelectedItem is Виды_товаров delete_category)
            {
                MessageBoxResult result = MessageBox.Show("Вы действительно хотите категорию?", "Обновление", MessageBoxButton.YesNo, MessageBoxImage.Question);
                            if (MessageBoxResult.Yes == result)
                {
                    foreach (var x in s.Виды_товаров)
                        if (x.Код_вида == delete_category.Код_вида)
                        {
                            s.Виды_товаров.Remove(x);
                            break;
                        }
                    s.SaveChanges();
                    //Очистка
                    CategoryList.SelectedIndex = -1;
                    NameCategory.Text = "";
                    MinPrice.Text = "";
                    CategoryList.SelectedIndex = -1;
                    CategoryList.Items.Clear();
                    foreach (var x in s.Виды_товаров)
                    {
                        CategoryList.Items.Add(x);
                    }
                    MessageBox.Show("Категория удалёна", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
                MessageBox.Show("Нет удаляемых объектов", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
