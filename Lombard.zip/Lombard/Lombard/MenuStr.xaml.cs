﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class MenuStr : Page
    {
        public MenuStr()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FR.MainFrame.Navigate(new Contract());
        }

        private void Workers_Click(object sender, RoutedEventArgs e)
        {
            FR.MainFrame.Navigate(new Workers());
        }

        private void Users_Click(object sender, RoutedEventArgs e)
        {
            FR.MainFrame.Navigate(new Users());
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Protect.admin_check == true)
            {
                BWorkers.Visibility = Visibility.Visible;
                BUsers.Visibility = Visibility.Visible;
                BTovars.Visibility = Visibility.Visible;
            }
            else
            {
                BWorkers.Visibility = Visibility.Hidden;
                BUsers.Visibility = Visibility.Hidden;
                BTovars.Visibility = Visibility.Visible;
            }
        }

        private void BTovars_Click(object sender, RoutedEventArgs e)
        {
            FR.MainFrame.Navigate(new Tovars());
        }
    }
}
