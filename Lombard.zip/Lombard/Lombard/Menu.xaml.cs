﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class Menu : Window
    {
        Entities en = new Entities();
        public Menu()
        {
            InitializeComponent();
            FR.MainFrame = MainFrame;
            MainFrame.Navigate(new MenuStr());//Открытие страницы с меню
            foreach (var x in en.Сотрудники)
            {
                if (save_idworker.idworker == x.Код_сотрудника)
                {
                    if(x.Отчество==null)
                        ФИО.Text = x.Фамилия.Trim() + " " + x.Имя.Trim();
                    else
                        ФИО.Text = x.Фамилия.Trim() + " " + x.Имя.Trim() + " " + x.Отчество.Trim();
                }
            }
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MainWindow s = new MainWindow();
            s.Show();
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            MainFrame.Navigate(new MenuStr());//Открытие главного меню
        }

        private void Image_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {
            MainFrame.Navigate(new Password());//Открытие страницы со сменой пароля
        }
    }
}
