﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            
        }
        Entities en = new Entities();
        //Авторизация
        private void enter_Click(object sender, RoutedEventArgs e)
        {
            bool flag = false;
            if (Logtext.Text != "" && Logtext.Text != null
               && Passtext.Password != "" && Passtext.Password != null)
            {
                string Login = Logtext.Text.Trim();
                string Password = Passtext.Password.Trim();
                foreach (var x in en.Пользователи)
                {
                    if (Login == x.Логин.Trim())
                    {
                        if (Password == x.Пароль.Trim())
                        {
                            save_role.idrole = x.Код_пользователя;//Сохранение кода пользователя
                            //Проверка на привязку к сотруднику
                            foreach (var g in en.Сотрудники)//Записываем код авторизированного сотрудника 
                            {
                                if (save_role.idrole == g.Пользователи.Код_пользователя)
                                {
                                    flag = true;
                                    save_idworker.idworker = g.Код_сотрудника;//Сохраняем код сотрудника
                                    if (x.Администратор == true)
                                    {
                                        Protect.admin_check = true;//Сохранение роли администратора
                                    }
                                    else
                                    {
                                        Protect.admin_check = false;
                                    }
                                    Menu s = new Menu();
                                    s.Show();
                                    Close();
                                    break;
                                }
                            }
                        }
                        else
                        {
                            flag = true;
                            MessageBox.Show("Пароль не правильный", "Проверьте данные", MessageBoxButton.OK, MessageBoxImage.Error);//Cообщение при неправильном вводе пароля
                            break;
                        }
                    }
                }
                if (!flag)
                {
                    MessageBox.Show("Логин не правильный", "Пользователя не существует", MessageBoxButton.OK, MessageBoxImage.Error);//Сообщение при не правильном вводе логина
                }
            }
            else
            {
                MessageBox.Show("Заполните поля!", "Забыл всё", MessageBoxButton.OK, MessageBoxImage.Error);//
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            save_role.idrole = 0;
            save_idworker.idworker = 0;
        }
    }
}
