﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class Users : Page
    {
        Entities s = new Entities();
        public Users()
        {
            InitializeComponent();
            foreach (var x in s.Пользователи)
            {
                ListUsers.Items.Add(x);
            }
        }

        private void Add_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ListUsers.SelectedIndex = -1;
            Login.Text = "";
            Password.Text = "";
            Admin.IsChecked = false;
        }

        private void Save_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Пользователи user = ListUsers.SelectedItem as Пользователи;
            Пользователи id_user = new Пользователи();
            if (Login.Text==""||Password.Text=="")
            {
                MessageBox.Show("Заполните все поля!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (ListUsers.SelectedIndex == -1)
                {
                    var reaedLogin = Login.Text;
                    var readedPassword = Password.Text;
                    var readedAdminCheck = Admin.IsChecked.Value;
                    var new_Users = new Пользователи
                    {
                        Логин = reaedLogin,
                        Пароль = readedPassword,
                        Администратор = readedAdminCheck
                    };
                    s.Пользователи.Add(new_Users);
                    s.SaveChanges();
                    ListUsers.Items.Clear();
                    foreach (var x in s.Пользователи)
                    {
                        ListUsers.Items.Add(x);
                    }
                    MessageBox.Show("Пользователь добавлен", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    //Сохранение клиента
                    Пользователи readedUser = ListUsers.SelectedItem as Пользователи;
                    readedUser.Логин = Login.Text;
                    readedUser.Пароль = Password.Text;
                    readedUser.Администратор = Admin.IsChecked.Value;
                    s.SaveChanges();
                    ListUsers.Items.Clear();
                    foreach (var x in s.Пользователи)
                    {
                        ListUsers.Items.Add(x);
                    }
                    MessageBox.Show("Данные пользователя изменены", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void ListUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Пользователи selected_user = ListUsers.SelectedItem as Пользователи;
            if (selected_user != null)
            {
                Login.Text = selected_user.Логин.Trim();
                Password.Text = selected_user.Пароль.Trim();
                Admin.IsChecked = selected_user.Администратор;
            }
        }

        private void Delete_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var delete_User = ListUsers.SelectedItem as Пользователи;
            bool flag = true;
            if (delete_User != null)
            {
                foreach (var x in s.Сотрудники)
                {
                    if (delete_User.Код_пользователя == x.Пользователи.Код_пользователя)
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag == true)
                {
                    s.Пользователи.Remove(delete_User);
                    s.SaveChanges();
                    Login.Text = "";
                    Password.Text = "";
                    Admin.IsChecked = false;
                    ListUsers.SelectedIndex = -1;
                    ListUsers.Items.Clear();
                    foreach (var x in s.Пользователи)
                        ListUsers.Items.Add(x);
                    MessageBox.Show("Пользователь удалён", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                if (flag == false)
                {
                    MessageBox.Show("Данный пользователь привязан к сотруднику,его нельзя удалить", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
                MessageBox.Show("Нет удаляемых объектов!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
