﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class Password : Page
    {
        Entities sw = new Entities();
        public Password()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (NewPassword.Text == "" || OldPassword.Text == "")
            {
                MessageBox.Show("Заполните поля!", "Поля пустые", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                foreach (var x in sw.Пользователи)
                {
                    if (x.Код_пользователя == save_iduser.id_user)
                    {
                        if (OldPassword.Text == x.Пароль.Trim())
                        {
                            Пользователи pass = x;
                            pass.Пароль = NewPassword.Text.Trim();
                            NewPassword.Clear();
                            OldPassword.Clear();
                            MessageBox.Show("Пароль сохранён", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                            break;
                        }
                        else
                            MessageBox.Show("Пароль не правильный,введите правильный пароль!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        break;
                    }
                }
                    sw.SaveChanges();//Сохраняем пароль
            }
        }
    }
}
