﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Lombard
{
    public partial class Договоры
    {
        public override string ToString()
        {
            return Номер_договора+" "+Дата_сдачи.Date.ToShortDateString();        
        }
    }
    public class Товары
    {
        public string Name { get; set; }
        public string Number { get; set; }
        public string Category { get; set; }
        public string Material { get; set; }
        public double Weight { get; set; }
        public int MinPrice { get; set; }
        public int Price { get; set; }
        public string Status { get; set; }
        public string DateSell { get; set; }
        public string Worker { get; set; }

    }
    public partial class Клиенты
    {
        public override string ToString()
        {
            return Фамилия+Имя+Отчество.ToString();
        }
    }
    public partial class Сотрудники
    {
        public override string ToString()
        {
            if(Отчество!=null)
                return Фамилия.Trim() + " " + Имя.Trim().Substring(0, 1) + ". "+Отчество.Trim().Substring(0, 1) + ".".ToString();
            else
                return Фамилия.Trim() + " " + Имя.Trim().ToString();

        }
    }
    public partial class Виды_товаров
    {
        public override string ToString()
        {
            return Наименование.ToString().Trim();
        }
    }
    public partial class Срок_хранения
    {
        public override string ToString()
        {
            return Количество_дней.ToString().Trim();
        }
    }
    public partial class Пользователи
    {
        public override string ToString()
        {
            return Логин.ToString();
        }
    }
    public partial class Роли
    {
        public override string ToString()
        {
            return Наименование.ToString();
        }
    }
    public static class save_role
    {
        public static int idrole { get; set; }
    }
    public static class save_idworker
    {
        public static int idworker { get; set; }
    }
    public static class save_iduser
    {
        public static int id_user { get; set; }
    }
    class FR
    {
        public static Frame MainFrame { get; set; }
    }
}
