﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Lombard
{
    public partial class Договоры
    {
        public override string ToString()
        {
            return Номер.ToString();        
        }
    }
    public partial class Клиенты
    {
        public override string ToString()
        {
            return Фамилия+Имя+Отчество.ToString();
        }
    }
    public partial class Сотрудники
    {
        public override string ToString()
        {
            return Фамилия.Trim()+ " " +Имя.Trim().Substring(0, 1) + ". " + Отчество.Trim().Substring(0, 1) + ".".ToString();
        }
    }
    public partial class Виды_товаров
    {
        public override string ToString()
        {
            return Наименование.ToString().Trim();
        }
    }
    public partial class Срок_хранения
    {
        public override string ToString()
        {
            return Количество_дней.ToString().Trim();
        }
    }
    public partial class Пользователи
    {
        public override string ToString()
        {
            return Логин.ToString();
        }
    }
    public static class save_role
    {
        public static int idrole { get; set; }
    }
    public static class save_idworker
    {
        public static int idworker { get; set; }
    }
    public static class Protect
    {
        public static bool admin_check { get; set; }
    }
    class FR
    {
        public static Frame MainFrame { get; set; }
    }
}
