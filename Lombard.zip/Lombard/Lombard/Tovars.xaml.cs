﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class Tovars : Page
    {
        Entities en = new Entities();
        public Tovars()
        {
            InitializeComponent();
            foreach (var x in en.Договоры)
            {
                if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты==0 || x.Сумма_выплаты==null)
                {
                    ListTovars.Items.Add(x);
                }
            }
            foreach (var x in en.Виды_товаров)
            {
                Category.Items.Add(x);
            }
        }

        private void ListTovars_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListTovars.SelectedItem is Договоры selected_contract)
            {
                //Подставление значение по договору
                NameProduct.Text = selected_contract.Наименование_товара.Trim();
                Category.SelectedItem = (from id in en.Виды_товаров where id.Код_вида == selected_contract.Виды_товаров.Код_вида select id).Single<Виды_товаров>();
                Price.Text = Convert.ToInt32(selected_contract.Оценка_товара).ToString();
                Metal.Text = selected_contract.Металл.Trim();
                Weight.Text = selected_contract.Вес.ToString();
                if (selected_contract.Статус_договора == true)//Отображение статуса,что товар продан
                {
                    StatusText.Foreground = Brushes.Red;
                    StatusText.Content = "Продан";
                }
                if (selected_contract.Статус_договора == false)//Отображение статуса,что товар в продаже
                {
                    StatusText.Foreground = Brushes.Green;
                    StatusText.Content = "В продаже";
                }
                //Проверка на пустое поле металл
                if (selected_contract.Металл.Trim() == null || selected_contract.Металл.Trim() == "" || selected_contract.Металл.Trim() == "Не указано")
                    Metal.Text = "Не указано";
                else
                    Metal.Text = selected_contract.Металл.Trim();
                //Проверка на пустое поле вес
                if (selected_contract.Вес == null || selected_contract.Вес == 0)
                    Weight.Text = "Не указано";
                else
                    Weight.Text = selected_contract.Вес.ToString();
            }
        }

        private void Category_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Category.SelectedIndex == 11)
            {
                LMetal.Visibility = Visibility.Visible;
                Metal.Visibility = Visibility.Visible;
                LWeight.Visibility = Visibility.Visible;
                Weight.Visibility = Visibility.Visible;
            }
            else
            {
                LMetal.Visibility = Visibility.Hidden;
                Metal.Visibility = Visibility.Hidden;
                LWeight.Visibility = Visibility.Hidden;
                Weight.Visibility = Visibility.Hidden;
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (ListTovars.SelectedIndex > -1)
            {
                if (Price.Text == "" || Category.SelectedIndex == -1 || NameProduct.Text == "")//Проверка пустых полей
                {
                    MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    //Считываем всё с полей в переменные
                    var readedContract = ListTovars.SelectedItem as Договоры;
                    var readedNProduct = NameProduct.Text.Trim();
                    var readedPrice = Price.Text.Trim();
                    var readedmetal = Metal.Text.Trim();
                    var readedWeight = Weight.Text.Trim();
                    var readedCategory = Category.SelectedItem as Виды_товаров;
                    //Проверка на пустые поля
                    if (Metal.Text.Trim() == null || Metal.Text.Trim() == "")
                        readedmetal = "Не указано";
                    else
                        readedmetal = Metal.Text.Trim();
                    if (Weight.Text.Trim() == null || Weight.Text.Trim() == "" || Weight.Text.Trim() == "Не указано")
                        readedWeight = null;
                    readedContract.Наименование_товара = readedNProduct;
                    readedContract.Виды_товаров = readedCategory;
                    readedContract.Оценка_товара = Convert.ToDecimal(readedPrice);
                    en.SaveChanges();
                    MessageBox.Show("Данные о товаре изменены", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                    int id_zapis = ListTovars.SelectedIndex;
                    //Обновляем список
                    ListTovars.Items.Clear();
                    foreach (var x in en.Договоры)
                    {
                        if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == 0 || x.Сумма_выплаты == null)
                        {
                            ListTovars.Items.Add(x);
                        }
                    }
                    ListTovars.SelectedIndex = id_zapis;
                }
            }
            else
            {
                MessageBox.Show("Выберите товар из списка", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Metal_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Metal.Text == "Не указано")
                Metal.Text = "";
        }

        private void Weight_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Weight.Text == "Не указано")
                Weight.Text = "";
        }

        private void Sell_Click(object sender, RoutedEventArgs e)
        {
            if (ListTovars.SelectedIndex > -1)
            {
                var readedContract = ListTovars.SelectedItem as Договоры;
                readedContract.Статус_договора = true;
                en.SaveChanges();
                MessageBox.Show("Товар продан", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                int id_zapis = ListTovars.SelectedIndex;
                //Обновляем список
                ListTovars.Items.Clear();
                foreach (var x in en.Договоры)
                {
                    if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == 0 || x.Сумма_выплаты == null)
                    {
                        ListTovars.Items.Add(x);
                    }
                }
                ListTovars.SelectedIndex = id_zapis;
            }
            else
            {
                MessageBox.Show("Выберите товар из списка", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Refund_Click(object sender, RoutedEventArgs e)
        {
            if (ListTovars.SelectedIndex > -1)
            {
                var readedContract = ListTovars.SelectedItem as Договоры;
                readedContract.Статус_договора = false;
                en.SaveChanges();
                MessageBox.Show("Товар снова в продаже", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                int id_zapis = ListTovars.SelectedIndex;
                //Обновляем список
                ListTovars.Items.Clear();
                foreach (var x in en.Договоры)
                {
                    if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == 0 || x.Сумма_выплаты == null)
                    {
                        ListTovars.Items.Add(x);
                    }
                }
                ListTovars.SelectedIndex = id_zapis;
            }
            else
            {
                MessageBox.Show("Выберите товар из списка", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Price_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Search_KeyDown(object sender, KeyEventArgs e)
        {
            //Поиск договора по кнопке "Enter"
            if (e.Key == Key.Enter)
            {
                if (Tsearch.Text.Trim() != "")
                {
                    foreach (var item in en.Договоры)
                    {
                        if (item.Номер == (Convert.ToInt32(Tsearch.Text.Trim())))
                        {
                            ListTovars.Items.Clear();
                            ListTovars.Items.Add(item);
                            break;
                        }
                    }
                }
                else
                    MessageBox.Show("Заполните поле поиска", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void Tsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Обновляем список при пустом поле поиска
            if (Tsearch.Text == "")
            {
                ListTovars.Items.Clear();
                foreach (var x in en.Договоры)
                {
                    if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == 0 || x.Сумма_выплаты == null)
                    {
                        ListTovars.Items.Add(x);
                    }
                }
            }
        }

        private void Search_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (Tsearch.Text.Trim() != "")
            {
                foreach (var item in en.Договоры)
                {
                    if (item.Номер == (Convert.ToInt32(Tsearch.Text.Trim())))
                    {
                        ListTovars.Items.Clear();
                        ListTovars.Items.Add(item);
                        break;
                    }
                }
            }
            else
                MessageBox.Show("Заполните поле поиска", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
