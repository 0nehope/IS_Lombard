﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class Workers : Page
    {
        Entities en = new Entities();
        public Workers()
        {
            InitializeComponent();
            foreach (var x in en.Пользователи)
            {
                Users.Items.Add(x);
            }
            foreach (var x in en.Сотрудники)
            {
                ListWorkers.Items.Add(x);
            }
        }

        private void Add_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //___________________________

            /*Информация о сотруднике
             __________________________*/
            ListWorkers.SelectedIndex = -1;
            Name.Text = "";
            LastName.Text = "";
            SecondName.Text = "";
            Number.Text = "";
            DateOFissue.SelectedDate = null;
            Country.Text = "";
            Region.Text = "";
            City.Text = "";
            Street.Text = "";
            Home.Text = "";
            Apartament.Text = "";
            Phone.Text = "";
            Users.SelectedIndex = -1;
        }

        private void Save_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            if (ListWorkers.SelectedIndex == -1)//Сохранение
            {
                //                                     ________________Проверка на пустые поля___________________
                if (Name.Text == "" || LastName.Text == "" || SecondName.Text == "" || Number.Text == "" || DateOFissue.SelectedDate == null || Country.Text == ""
                    || Region.Text == "" || City.Text == "" || Home.Text == "" || Street.Text=="" || Phone.Text == "" || Users.SelectedIndex == -1)
                {
                    MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    //Сотрудник
                    var readedname = Name.Text.Trim();
                    var readedlastname = LastName.Text.Trim();
                    var readedSecondname = SecondName.Text.Trim();
                    var readedNumber = Number.Text.Trim();
                    DateTime readedDateOFissue = DateOFissue.SelectedDate.Value;
                    var readedCountry = Country.Text.Trim();
                    var readedRegion = Region.Text.Trim();
                    var readedCity = City.Text.Trim();
                    var readedStreet = Street.Text.Trim();
                    var readedHome = Home.Text.Trim();
                    var readedApartament = Apartament.Text.Trim();
                    var readedPhone = Phone.Text.Trim();
                    Пользователи readedUser = Users.SelectedItem as Пользователи;
                    Сотрудники saveUser = ListWorkers.SelectedItem as Сотрудники;
                    //Проверка необзательных полей
                    if (SecondName.Text.Trim() == null || SecondName.Text.Trim() == "" || SecondName.Text.Trim() == "Не указано")
                        readedSecondname = null;
                    else
                        readedSecondname = SecondName.Text.Trim();
                    if (Apartament.Text.Trim() == null || Apartament.Text.Trim() == "" || Apartament.Text.Trim() == "Не указано")
                        readedApartament = null;
                    else
                        readedApartament = Apartament.Text.Trim();
                    var new_workers = new Сотрудники
                    {
                        Фамилия = readedlastname,
                        Имя = readedname,
                        Отчество = readedSecondname,
                        Серия_номер = readedNumber,
                        Дата_выдачи = readedDateOFissue,
                        Страна = readedCountry,
                        Регион = readedRegion,
                        Населённый_пункт = readedCity,
                        Улица = readedStreet,
                        Номер_дома = Convert.ToInt32(readedHome),
                        Номер_квартиры = Convert.ToInt32(readedApartament),
                        Телефон = readedPhone,
                        Пользователи = Users.SelectedItem as Пользователи
                    };
                    //Сохранение сотрудника
                    en.Сотрудники.Add(new_workers);
                    en.SaveChanges();
                    //__________Обновление списка____________
                    ListWorkers.Items.Clear();
                    foreach (var x in en.Сотрудники)
                    {
                        ListWorkers.Items.Add(x);
                    }
                    MessageBox.Show("Данные о сотруднике сохранены", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                //                                      ________________Проверка на пустые поля___________________
                if (Name.Text == "" || LastName.Text == "" || SecondName.Text == "" || Number.Text == "" || DateOFissue.SelectedDate == null || Country.Text == ""
                || Region.Text == "" || City.Text == "" || Home.Text == "" || Street.Text==""|| Phone.Text == "" || Users.SelectedIndex == -1)
                {
                    MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    //Сотрудник
                    var readedname = Name.Text.Trim();
                    var readedlastname = LastName.Text.Trim();
                    var readedSecondname = SecondName.Text.Trim();
                    var readedNumber = Number.Text.Trim();
                    DateTime readedDateOFissue = DateOFissue.SelectedDate.Value;
                    var readedCountry = Country.Text.Trim();
                    var readedRegion = Region.Text.Trim();
                    var readedCity = City.Text.Trim();
                    var readedStreet = Street.Text.Trim();
                    var readedHome = Home.Text.Trim();
                    var readedApartament = Apartament.Text.Trim();
                    var readedPhone = Phone.Text.Trim();
                    Пользователи readedUser = Users.SelectedItem as Пользователи;
                    Сотрудники saveUser = ListWorkers.SelectedItem as Сотрудники;
                    //Проверка необзательных полей
                    if (SecondName.Text.Trim() == null || SecondName.Text.Trim() == "" || SecondName.Text.Trim() == "Не указано")
                        readedSecondname = null;
                    else
                        readedSecondname = SecondName.Text.Trim();
                    if (Apartament.Text.Trim() == null || Apartament.Text.Trim() == "" || Apartament.Text.Trim() == "Не указано")
                        readedApartament = null;
                    else
                        readedApartament = Apartament.Text.Trim();
                    //Проверка необзательных полей
                    if (SecondName.Text.Trim() == null || SecondName.Text.Trim() == "" || SecondName.Text.Trim() == "Не указано")
                        readedSecondname = null;
                    else
                        readedSecondname = SecondName.Text.Trim();
                    if (Apartament.Text.Trim() == null || Apartament.Text.Trim() == "" || Apartament.Text.Trim() == "Не указано")
                        readedApartament = null;
                    else
                        readedApartament = Apartament.Text.Trim();
                    //Списываем всё с полей в переменные
                    Сотрудники readWork = ListWorkers.SelectedItem as Сотрудники;
                    readWork.Имя = readedname;
                    readWork.Фамилия = readedlastname;
                    readWork.Отчество = readedSecondname;
                    readWork.Серия_номер = readedNumber;
                    readWork.Дата_выдачи = readedDateOFissue;
                    readWork.Страна = readedCountry;
                    readWork.Регион = readedRegion;
                    readWork.Населённый_пункт = readedCity;
                    readWork.Номер_дома = Convert.ToInt32(readedHome);
                    readWork.Улица = readedStreet;
                    readWork.Номер_квартиры = Convert.ToInt32(readedApartament);
                    readWork.Телефон = readedPhone;
                    readWork.Пользователи = Users.SelectedItem as Пользователи;
                    en.SaveChanges();
                    //__________Обновление списка____________
                    ListWorkers.Items.Clear();
                    foreach (var x in en.Сотрудники)
                    {
                        ListWorkers.Items.Add(x);
                    }
                    MessageBox.Show("Данные о сотруднике изменены", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void Delete_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            bool flag = false;
            if (ListWorkers.SelectedItem is Сотрудники delete_worker)
            {
                    Договоры id_worker = new Договоры();
                Пользователи del_userWK = delete_worker.Пользователи;
                    if(delete_worker.Код_сотрудника==save_idworker.idworker)//Проверка на использование сотрудника в другой таблице
                    {
                    MessageBox.Show("Сотрудник не может быть удалён,так как данный сотрудник авторизирован", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Error);
                    flag = true;
                    }
                foreach (var t in en.Договоры)
                {
                    if (delete_worker.Код_сотрудника == t.Сотрудники.Код_сотрудника)
                    {
                        MessageBox.Show("Сотрудник не может быть удалён,так как данный сотрудник оформлен в договоре", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Error);
                        flag = true;
                        break;
                    }
                }
                if (flag == false)
                {

                    foreach (var x in en.Сотрудники)
                        if (x.Код_сотрудника == delete_worker.Код_сотрудника)
                        {
                            en.Сотрудники.Remove(x);
                            break;
                        }
                    //Удаляем вслед за сотрудником его пользователя
                    foreach (var x in en.Пользователи)
                        if (x.Код_пользователя == del_userWK.Код_пользователя)
                        {
                            en.Пользователи.Remove(x);
                            break;
                        }
                    en.SaveChanges();
                    ListWorkers.SelectedIndex = -1;
                    //___________________________

                    /*Информация о сотруднике
                     __________________________*/
                    Name.Clear();
                    LastName.Clear();
                    SecondName.Clear();
                    Number.Clear();
                    DateOFissue.SelectedDate = null;
                    Country.Clear();
                    Region.Clear();
                    City.Clear();
                    Street.Clear();
                    Home.Clear();
                    Apartament.Clear();
                    Phone.Clear();
                    //Обновляем список
                    ListWorkers.Items.Clear();
                    Users.SelectedIndex = -1;
                    foreach (var x in en.Сотрудники)
                        ListWorkers.Items.Add(x);
                    MessageBox.Show("Сотрудник удалён", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
                MessageBox.Show("Нет удаляемых объектов", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void ListWorkers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListWorkers.SelectedItem is Сотрудники selected_contract)
            {
                //Подставление значение по Клиенту
                Name.Text = selected_contract.Имя.Trim().ToString();
                LastName.Text = selected_contract.Фамилия.Trim();
                //Проверка на пустое поле Фамилии
                if (selected_contract.Отчество.Trim() == null || selected_contract.Отчество == "")
                    SecondName.Text = "Не указано";//Если поле пустое
                else
                    SecondName.Text = selected_contract.Отчество.Trim();//Если оно заполнено
                if (selected_contract.Номер_квартиры == null || selected_contract.Номер_квартиры == 0)
                    Apartament.Text = "Не указано";//Если поле поле пустое
                else
                    Apartament.Text = selected_contract.Номер_квартиры.ToString();
                Number.Text = selected_contract.Серия_номер.Trim();
                DateOFissue.SelectedDate = selected_contract.Дата_выдачи;
                Country.Text = selected_contract.Страна.Trim();
                Region.Text = selected_contract.Регион.Trim();
                City.Text = selected_contract.Населённый_пункт.Trim();
                Street.Text = selected_contract.Улица.Trim();
                Home.Text = selected_contract.Номер_дома.ToString();
                Users.SelectedItem = (from id in en.Пользователи where id.Код_пользователя == selected_contract.Пользователи.Код_пользователя select id).Single<Пользователи>();
                Phone.Text = selected_contract.Телефон;
            }
        }

        private void Apartament_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Apartament.Text == "Не указано")
                Apartament.Text = "";
        }

        private void SecondName_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SecondName.Text == "Не указано")
                SecondName.Text = "";
        }

        private void Phone_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Apartament_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Home_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Number_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }
    }
}
