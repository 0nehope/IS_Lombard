﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{

    public partial class TovarsPage : Page
    {
        Entities s = new Entities();
        public TovarsPage()
        {
            InitializeComponent();
        }
        public void Load()
        {
            DGridTovars.Items.Clear();
            DateTime Date30Days = new DateTime();//Переменная для подсчёта даты
            foreach (var x in s.Договоры)
            {
                if (x.Дата_продажи != null)
                {
                    Date30Days = x.Дата_продажи.Value.AddDays(30);//Месяц после продажи
                }
                if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == null && x.Дата_продажи != null 
                    && DateTime.Now <= Date30Days)//Все просроченные - не выплаченные договоры
                {
                    Товары tovar = new Товары
                    {
                        Number = x.Номер_договора.Trim(),
                        Name = x.Наименование_товара.Trim(),
                        Category = x.Виды_товаров.Наименование.Trim(),
                        MinPrice = Convert.ToInt32(x.Виды_товаров.МинЦена),
                        Price = Convert.ToInt32(x.Оценка_товара),
                    };
                    //Проверки на пустые поля
                    //_______________________
                    if (x.Сотрудники.Отчество == null)
                        tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim();
                    else
                        tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim().Substring(0, 1) 
                            + ". " + x.Сотрудники.Отчество.Trim().Substring(0, 1) + ".";
                    if (x.Металл != null)
                        tovar.Material = x.Металл.Trim();
                    if (x.Вес != null)
                        tovar.Weight =Convert.ToDouble(x.Вес);
                    //________________________
                    if (x.Статус_договора == true)
                        tovar.Status = "Продано";
                    else
                        tovar.Status = "В продаже";
                    tovar.DateSell = x.Дата_продажи.Value.ToString();
                    DGridTovars.Items.Add(tovar);
                    Count.Text = "Кол-во товаров: " + DGridTovars.Items.Count.ToString();
                }
                if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == null && x.Дата_продажи ==null)//Все просроченные - не выплаченные договоры
                {
                    Товары tovar = new Товары
                    {
                        Number = x.Номер_договора.Trim(),
                        Name = x.Наименование_товара.Trim(),
                        Category = x.Виды_товаров.Наименование.Trim(),
                        MinPrice = Convert.ToInt32(x.Виды_товаров.МинЦена),
                        Price = Convert.ToInt32(x.Оценка_товара),
                    };
                    //Проверки на пустые поля
                    //_______________________
                    if (x.Сотрудники.Отчество == null)
                        tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim();
                    else
                        tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim().Substring(0, 1) 
                            + ". " + x.Сотрудники.Отчество.Trim().Substring(0, 1) + ".";
                    if (x.Металл != null)
                        tovar.Material = x.Металл.Trim();
                    if (x.Вес != null)
                        tovar.Weight = Convert.ToDouble(x.Вес);
                    //________________________
                    if (x.Статус_договора == true)
                        tovar.Status = "Продано";
                    else
                        tovar.Status = "В продаже";
                    DGridTovars.Items.Add(tovar);
                    Count.Text = "Кол-во товаров: " + DGridTovars.Items.Count.ToString();
                }
            }
            if(DGridTovars.Items.Count==0)
            {
                Count.Text = "Кол-во товаров: " + DGridTovars.Items.Count.ToString();
            }            
        }       
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Load();
        }
        private string Tovar_Text(int number)//Для определения окончания
        {
            if (((number % 100) > 10) && ((number % 100) < 20))
                return "товаров";
            if (number % 10 == 1)
                return "товар";
            if ((number % 10 == 2) || (number % 10 == 3) || (number % 10 == 4))
                return "товара";
            return "товаров";
        }
        private void return_Click(object sender, RoutedEventArgs e)
        {
            if (DGridTovars.SelectedItems.Count != 0)
            {
                var TovarsForReturn = DGridTovars.SelectedItems.Cast<Товары>().ToList();
                string count_tovar_txt = Tovar_Text(TovarsForReturn.Count);
                if (MessageBox.Show($"Вы действительно хотите вернуть {TovarsForReturn.Count()} " + count_tovar_txt, "Обновление",
              MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        var selectedItem = DGridTovars.SelectedItems as Товары;
                        Договоры edit_contract = null;
                        bool flag = false;
                        foreach (var x in s.Договоры)
                        {
                            foreach (var g in TovarsForReturn)
                            {
                                if (g.Number.Trim() == x.Номер_договора.Trim())
                                {
                                    flag = true;
                                    edit_contract = x;
                                }
                                if (flag == true)
                                {
                                    edit_contract.Статус_договора = false;
                                    edit_contract.Дата_продажи = null;
                                }
                            }
                        }
                        MessageBox.Show("Выбранные товары возвращены", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                        s.SaveChanges();
                        Load();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
            else
                MessageBox.Show("Товары не выбраны,выберите товар!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Sell_Click(object sender, RoutedEventArgs e)
        {
            if (DGridTovars.SelectedItems.Count != 0)
            {
                var TovarsForReturn = DGridTovars.SelectedItems.Cast<Товары>().ToList();
                string count_tovar_txt = Tovar_Text(TovarsForReturn.Count);
                if (MessageBox.Show($"Вы действительно хотите продать {TovarsForReturn.Count()} " + count_tovar_txt, "Обновление",
              MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        var selectedItem = DGridTovars.SelectedItems as Товары;
                        Договоры edit_contract = null;
                        bool flag = false;
                        foreach (var x in s.Договоры)
                        {
                            foreach (var g in TovarsForReturn)
                            {
                                if (g.Number.Trim() == x.Номер_договора.Trim())
                                {
                                    flag = true;
                                    edit_contract = x;
                                }
                                if (flag == true)
                                {
                                    edit_contract.Статус_договора = true;
                                    edit_contract.Дата_продажи = DateTime.Now;
                                }
                            }
                        }
                        s.SaveChanges();
                        Load();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
                }
            }
            else
                MessageBox.Show("Товары не выбраны,выберите товар!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            FR.MainFrame.Navigate(new EditTovarPG((sender as Button).DataContext as Товары));
        }

        private void Search_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Search.Text == "Введите наименование товара или номер")
                Search.Text = "";
        }
        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Search.Text != "" && Search.Text != "Введите наименование товара или номер")
            {
                //Заполнение листа
                //____________________________
                DGridTovars.Items.Clear();
                List<Товары> List = new List<Товары>();
                DateTime Date30Days = new DateTime();//Для подсчёта даты
                foreach (var x in s.Договоры)
                {
                    if (x.Дата_продажи != null)
                    {
                        Date30Days = x.Дата_продажи.Value.AddDays(30);//Месяц после продажи
                    }
                    if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == null && x.Дата_продажи != null && 
                        DateTime.Now <= Date30Days)//Все просроченные - не выплаченные договоры
                    {
                        if ((x.Наименование_товара.ToLower().Trim().Contains(Search.Text.ToLower().Trim())) 
                            || (x.Номер_договора.Contains(Search.Text.Trim())))
                        {
                            Товары tovar = new Товары
                            {
                                Number = x.Номер_договора.Trim(),
                                Name = x.Наименование_товара.Trim(),
                                Category = x.Виды_товаров.Наименование.Trim(),
                                MinPrice = Convert.ToInt32(x.Виды_товаров.МинЦена),
                                Price = Convert.ToInt32(x.Оценка_товара),
                            };
                            //Проверки на пустые поля
                            //_______________________
                            if (x.Сотрудники.Отчество == null)
                                tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim();
                            else
                                tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim().Substring(0, 1) + 
                                    ". " + x.Сотрудники.Отчество.Trim().Substring(0, 1) + ".";
                            if (x.Металл != null)
                                tovar.Material = x.Металл.Trim();
                            if (x.Вес != null)
                                tovar.Weight = Convert.ToInt32(x.Вес);
                            //________________________
                            if (x.Статус_договора == true)
                                tovar.Status = "Продано";
                            else
                                tovar.Status = "В продаже";
                            DGridTovars.Items.Add(tovar);
                        }
                    }
                    if (DateTime.Now > x.Дата_погашения && x.Сумма_выплаты == null 
                        && x.Дата_продажи == null)//Все просроченные - не выплаченные договоры
                    {
                        if ((x.Наименование_товара.ToLower().Trim().Contains(Search.Text.ToLower().Trim())) 
                            || (x.Номер_договора.Contains(Search.Text.Trim())))
                        {
                            Товары tovar = new Товары
                            {
                                Number = x.Номер_договора.Trim(),
                                Name = x.Наименование_товара.Trim(),
                                Category = x.Виды_товаров.Наименование.Trim(),
                                MinPrice = Convert.ToInt32(x.Виды_товаров.МинЦена),
                                Price = Convert.ToInt32(x.Оценка_товара),
                            };
                            //Проверки на пустые поля
                            //_______________________
                            if (x.Сотрудники.Отчество == null)
                                tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim();
                            else
                                tovar.Worker = x.Сотрудники.Фамилия.Trim() + " " + x.Сотрудники.Имя.Trim().Substring(0, 1) 
                                    + ". " + x.Сотрудники.Отчество.Trim().Substring(0, 1) + ".";
                            if (x.Металл != null)
                                tovar.Material = x.Металл.Trim();
                            if (x.Вес != null)
                                tovar.Weight = Convert.ToDouble(x.Вес);
                            //________________________
                            if (x.Статус_договора == true)
                                tovar.Status = "Продано";
                            else
                                tovar.Status = "В продаже";
                            DGridTovars.Items.Add(tovar);
                            Count.Text = "Кол-во товаров: " + DGridTovars.Items.Count.ToString();
                        }
                    }
                }
                Count.Text = "Кол-во товаров: " + DGridTovars.Items.Count.ToString();
            }
            if (Search.Text == "")
            {
                Load();
            }
        }
    }
}
