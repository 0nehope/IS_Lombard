﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class Contract : Page
    {
        Entities en = new Entities();
        public Contract()
        {
            InitializeComponent();
            Worker.IsEnabled = false;
            foreach (var x in en.Сотрудники)
            {
                if (x.Код_сотрудника == Convert.ToInt32(save_idworker.idworker))
                {  
                    if(x.Отчество==null)
                        Worker.Text = x.Фамилия.Trim() + " " + x.Имя.Trim();
                    else
                        Worker.Text = x.Фамилия.Trim() + " " + x.Имя.Substring(0,1)+ ". " + x.Отчество.Substring(0,1)+".";
                }
            }
        }

        private void Add_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            /*Информация о договоре
            ________________________________*/
            ListContract.SelectedIndex = -1;
            NumberContract.Clear();
            NameProduct.Text = "";
            Category.SelectedIndex = -1;
            Period.SelectedIndex = -1;
            DateofDilivery.SelectedDate = null;
            MaturityDate.SelectedDate = null;
            Status.IsChecked = false;
            StatusText.Content = "";
            ProductEvolation.Text = "";
            SummCount.Text = "";
            AmountPayment.Text = "";
            StatusText.Content = "";
            Metal.Text = "";
            Weight.Text = "";
            foreach (var x in en.Сотрудники)
            {
                if (x.Код_сотрудника == Convert.ToInt32(save_idworker.idworker))
                {
                    Worker.Text = x.Фамилия.Trim() + " " + x.Имя.Substring(0, 1) + ". " + x.Отчество.Substring(0, 1) + ".";
                }
            }
            //___________________________

            /*Информация о клиенте
             __________________________*/
            Name.Text = "";
            LastName.Text = "";
            SecondName.Text = "";
            Number.Text = "";
            DateOFissue.SelectedDate = null;
            Country.Text = "";
            Region.Text = "";
            Street.Text = "";
            City.Text = "";
            Home.Text = "";
            Apartament.Text = "";
            Phone.Text = "";
            SummAmount.Content = "";
            Percent.Content = "";
            RWork.Visibility = Visibility.Hidden;
        }

        private void Save_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if(NameProduct.Text == "" ||NumberContract.Text==""|| Category.SelectedIndex == -1 || Period.SelectedIndex == -1
            || DateofDilivery.SelectedDate.HasValue == false || MaturityDate.SelectedDate.Value == null || ProductEvolation.Text == ""
            || SummCount.Text == "" || Name.Text == ""
            || LastName.Text == "" || Number.Text == "" || DateOFissue.SelectedDate.HasValue==false|| Country.Text == ""
            || Region.Text == "" || City.Text == "" || Street.Text=="" || Home.Text == "" || Phone.Text == "")
            {
                MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (ListContract.SelectedItem == null)//Если договор не выбран из списка
                {
                    MessageBoxResult result = MessageBox.Show("Вы действительно хотите создать договор?", "Обновление", MessageBoxButton.YesNo,MessageBoxImage.Question);
                    if (MessageBoxResult.Yes == result)
                    {
                        if (NumberContract.Text.Length == 10)//Проверка на номер договора
                        {
                            if (Number.Text.Length == 10)//Проверка на серию и номер паспорта
                            {
                                    int readedPrice = Convert.ToInt32(ProductEvolation.Text);
                                    var minprice = Category.SelectedItem as Виды_товаров;
                                    if (readedPrice < minprice.МинЦена)//Проверка на минимальную цену категории товара
                                    {
                                        MessageBox.Show("Цена товара не должна быть ниже минимальной", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                        ProductEvolation.Text = Convert.ToInt32(minprice.МинЦена).ToString();
                                    }
                                    else
                                    {
                                        int readed_summa_zaima = Convert.ToInt32(SummCount.Text);//Считываем сумма займа
                                        int ProductEv = (Convert.ToInt32(ProductEvolation.Text));
                                        if (readed_summa_zaima < ProductEv)//Проверка на то, что сумма займа меньше чем оценка товара
                                        {
                                            var readed_Contract = ListContract.SelectedItem as Contract;
                                            //Переписываем всё в переменные
                                            //Договор
                                            var readednumberContract = NumberContract.Text.Trim();
                                            var readednameProduct = NameProduct.Text.Trim();
                                            var readedCategory = Category.SelectedItem;
                                            var readedPeriod = Period.SelectedItem;
                                            DateTime readed_dataOfDilivery = DateofDilivery.SelectedDate.Value;
                                            DateTime readedMaturityDate = MaturityDate.SelectedDate.Value;
                                            var readedProductEvolation = ProductEvolation.Text.Trim();
                                            var readedSummCount = Convert.ToDecimal(SummCount.Text.Trim());
                                            var readedAmountPayment = AmountPayment.Text.Trim();
                                            var readedmetal = Metal.Text.Trim();
                                            var readedWeight = Weight.Text.Trim();
                                            Сотрудники readedidWorker = new Сотрудники();
                                            foreach (var x in en.Сотрудники)
                                            {
                                                if (x.Код_сотрудника == save_idworker.idworker)
                                                    readedidWorker = x;
                                            }
                                            var readedstatus = Status.IsChecked.Value;
                                            //Клиент
                                            var readedname = Name.Text.Trim();
                                            var readedlastname = LastName.Text.Trim();
                                            var readedSecondname = SecondName.Text.Trim();
                                            var readedNumber = Number.Text.Trim();
                                            DateTime readedDateOFissue = DateOFissue.SelectedDate.Value;
                                            var readedCountry = Country.Text.Trim();
                                            var readedRegion = Region.Text.Trim();
                                            var readedStreet = Street.Text.Trim();
                                            var readedCity = City.Text.Trim();
                                            var readedHome = Home.Text.Trim();
                                            var readedApartament = Apartament.Text.Trim();
                                            var readedPhone = Phone.Text.Trim();
                                            Клиенты readedIdClient = new Клиенты();
                                            if (ListContract.SelectedIndex == -1)//Сохранение
                                            {
                                                var new_client = new Клиенты
                                                {
                                                    Фамилия = readedlastname,
                                                    Имя = readedname,
                                                    Серия_номер = readedNumber,
                                                    Дата_выдачи = readedDateOFissue,
                                                    Страна = readedCountry,
                                                    Регион = readedRegion,
                                                    Населённый_пункт = readedCity,
                                                    Улица = readedStreet,
                                                    Номер_дома = Convert.ToInt32(readedHome),
                                                    Телефон = readedPhone
                                                };
                                                //Проверка необзательных полей клиента
                                                //_____________________________________________
                                                if (SecondName.Text.Trim() == null || SecondName.Text.Trim() == "" || SecondName.Text.Trim() == "Не указано")
                                                {
                                                    //Ничего не делаем
                                                }
                                                else
                                                    new_client.Отчество = readedSecondname;
                                                if (Apartament.Text.Trim() == null || Apartament.Text.Trim() == "" || Apartament.Text.Trim() == "Не указано")
                                                {
                                                    //Ничего не делаем
                                                }
                                                else
                                                    new_client.Номер_квартиры = Convert.ToInt32(readedApartament);
                                                //______________________________________________
                                                //Сохранение клиента
                                                en.Клиенты.Add(new_client);
                                                en.SaveChanges();
                                                //Поиск айдишника только что сохранённого клиента
                                                foreach (var x in en.Клиенты)
                                                    if (x.Фамилия.Trim() == readedlastname && x.Имя.Trim() == readedname && x.Серия_номер.Trim() == readedNumber
                                                        && x.Страна.Trim() == readedCountry && x.Регион.Trim() == readedRegion && x.Населённый_пункт.Trim() == readedCity
                                                        && x.Улица == readedStreet && x.Номер_дома == Convert.ToInt32(readedHome) && x.Телефон.Trim() == readedPhone)
                                                    {
                                                        readedIdClient = x;
                                                    }
                                                var new_Contract = new Договоры
                                                {
                                                    Номер_договора = readednumberContract,
                                                    Наименование_товара = readednameProduct,
                                                    Дата_сдачи = readed_dataOfDilivery,
                                                    Дата_погашения = readedMaturityDate,
                                                    Статус_договора = readedstatus,
                                                    Клиенты = readedIdClient,
                                                    Оценка_товара = Convert.ToDecimal(readedProductEvolation),
                                                    Сумма_займа = Convert.ToDecimal(readedSummCount),
                                                    Виды_товаров = Category.SelectedItem as Виды_товаров,
                                                    Срок_хранения = Period.SelectedItem as Срок_хранения,
                                                    Сотрудники = readedidWorker,
                                                };
                                                //Проверка необзательных полей договора
                                                //_____________________________________________
                                                if (Metal.Text.Trim() == null || Metal.Text.Trim() == "")
                                                {
                                                    //Ничего не делаем
                                                }
                                                else
                                                    new_Contract.Металл = readedmetal;
                                                if (Weight.Text.Trim() == null || Weight.Text.Trim() == "")
                                                {
                                                    //Ничего не делаем
                                                }
                                                else
                                                    new_Contract.Вес = Convert.ToDouble(readedWeight);
                                                if (AmountPayment.Text.Trim() == null || AmountPayment.Text.Trim() == "" || AmountPayment.Text == "Не указано")
                                                {
                                                    //Ничего не делаем
                                                }
                                                else
                                                    new_Contract.Сумма_выплаты = Convert.ToDecimal(readedAmountPayment);
                                                //______________________________________________
                                                en.Договоры.Add(new_Contract);
                                                en.SaveChanges();
                                                //Сохранение договора
                                                ListContract.Items.Clear();

                                                //________________очистка полей__________________________
                                                /*Информация о договоре
                                                _____________*/
                                                ListContract.SelectedIndex = -1;
                                                NameProduct.Text = "";
                                                Category.SelectedIndex = -1;
                                                Period.SelectedIndex = -1;
                                                DateofDilivery.SelectedDate = null;
                                                MaturityDate.SelectedDate = null;
                                                Status.IsChecked = false;
                                                StatusText.Content = "";
                                                ProductEvolation.Text = "";
                                                SummCount.Text = "";
                                                AmountPayment.Text = "";
                                                StatusText.Content = "";
                                                Metal.Text = "";
                                                Weight.Text = "";
                                                foreach (var x in en.Сотрудники)
                                                {
                                                    if (x.Код_сотрудника == Convert.ToInt32(save_idworker.idworker))
                                                    {
                                                        Worker.Text = x.Фамилия.Trim() + " " + x.Имя.Substring(0, 1) + ". " + x.Отчество.Substring(0, 1) + ".";
                                                    }
                                                }
                                                //___________________________

                                                /*Информация о клиенте
                                                 __________________________*/
                                                Name.Text = "";
                                                LastName.Text = "";
                                                SecondName.Text = "";
                                                NumberContract.Text = "";
                                                Number.Text = "";
                                                DateOFissue.SelectedDate = null;
                                                Country.Text = "";
                                                Region.Text = "";
                                                Street.Text = "";
                                                City.Text = "";
                                                Home.Text = "";
                                                Apartament.Text = "";
                                                Phone.Text = "";
                                                SummAmount.Content = "";
                                                RWork.Visibility = Visibility.Hidden;
                                                //___________________________________________________
                                                foreach (var x in en.Договоры)
                                                {
                                                    if (DateTime.Now < x.Дата_погашения)
                                                    {
                                                        ListContract.Items.Add(x);
                                                    }
                                                }
                                                MessageBox.Show("Договор создан", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                                            }
                                        }
                                        else
                                            MessageBox.Show("Сумма займа должна быть меньше оценки товара!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                    }
                            }
                            else
                                MessageBox.Show("Серия и номер паспорта должны состовлять 10 цифр\n Введите корректное значение!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        else
                            MessageBox.Show("Номер договора должен состовлять 10 символов\n Введите корректное значение!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                //_________________Сохранение договора___________________________________
                else
                {
                    MessageBoxResult result = MessageBox.Show("Вы действительно хотите изменить договор?", "Обновление", MessageBoxButton.YesNo,MessageBoxImage.Question);
                    if (MessageBoxResult.Yes == result)
                    {  
                        if (NumberContract.Text.Length == 10)//Проверка на номер договора
                        {
                            if (Number.Text.Length == 10)//Проверка на серию и номер паспорта
                            {
                                int readedPrice = Convert.ToInt32(ProductEvolation.Text);
                                var minprice = Category.SelectedItem as Виды_товаров;
                                if (readedPrice < minprice.МинЦена)//Проверка на минимальную цену категории товара
                                {
                                    MessageBox.Show("Цена товара не должна быть ниже минимальной", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                    ProductEvolation.Text = Convert.ToInt32(minprice.МинЦена).ToString();
                                }
                                else
                                {
                                    int readed_summa_zaima = Convert.ToInt32(SummCount.Text);//Считываем сумма займа
                                    int ProductEv = (Convert.ToInt32(ProductEvolation.Text));
                                    if (readed_summa_zaima < ProductEv)//Проверку на то что сумма займа меньше чем оценка товара
                                    {
                                        //Считываем клиента и его договор
                                        var readedContract = ListContract.SelectedItem as Договоры;
                                        //Договор
                                        //Очистка полей
                                        var readednumberContract = NumberContract.Text.Trim();
                                        var readednameProduct = NameProduct.Text.Trim();
                                        var readedCategory = Category.SelectedItem;
                                        var readedPeriod = Period.SelectedItem;
                                        DateTime readed_dataOfDilivery = DateofDilivery.SelectedDate.Value;
                                        DateTime readedMaturityDate = MaturityDate.SelectedDate.Value;
                                        var readedProductEvolation = ProductEvolation.Text.Trim();
                                        var readedSummCount = Convert.ToDecimal(SummCount.Text.Trim());
                                        var readedAmountPayment = AmountPayment.Text.Trim();
                                        var readedmetal = Metal.Text.Trim();
                                        var readedWeight = Weight.Text.Trim();
                                        Сотрудники readedidWorker = new Сотрудники();
                                        foreach (var x in en.Сотрудники)
                                        {
                                            if (x.Код_сотрудника == save_idworker.idworker)
                                                readedidWorker = x;
                                        }
                                        var readedstatus = Status.IsChecked.Value;
                                        //Клиент
                                        var readedname = Name.Text.Trim();
                                        var readedlastname = LastName.Text.Trim();
                                        var readedSecondname = SecondName.Text.Trim();
                                        var readedNumber = Number.Text.Trim();
                                        DateTime readedDateOFissue = DateOFissue.SelectedDate.Value;
                                        var readedCountry = Country.Text.Trim();
                                        var readedRegion = Region.Text.Trim();
                                        var readedStreet = Street.Text.Trim();
                                        var readedCity = City.Text.Trim();
                                        var readedHome = Home.Text.Trim();
                                        var readedApartament = Apartament.Text.Trim();
                                        var readedPhone = Phone.Text.Trim();
                                        Клиенты readedClient = null;                                       
                                        //Поиск клиента по контракту
                                        foreach (Клиенты x in en.Клиенты)
                                        {
                                            if (readedContract.Клиенты.Код_Клиента == x.Код_Клиента)
                                                readedClient = x;
                                        }
                                        //Изменяем существующие записи
                                        //О клиенте
                                        readedClient.Имя = readedname;
                                        readedClient.Фамилия = readedlastname;
                                        readedClient.Серия_номер = readedNumber;
                                        readedClient.Дата_выдачи = readedDateOFissue;
                                        readedClient.Страна = readedCountry;
                                        readedClient.Регион = readedRegion;
                                        readedClient.Населённый_пункт = readedCity;
                                        readedClient.Улица = readedStreet;
                                        readedClient.Номер_дома = Convert.ToInt32(readedHome);
                                        //Проверка необзательных полей клиента
                                        //_____________________________________________
                                        if (SecondName.Text.Trim() == null || SecondName.Text.Trim() == "" || SecondName.Text.Trim() == "Не указано")
                                        {
                                            //Ничего не делаем
                                        }
                                        else
                                            readedClient.Отчество = readedSecondname;
                                        if (Apartament.Text.Trim() == null || Apartament.Text.Trim() == "" || Apartament.Text.Trim() == "Не указано")
                                        {
                                            //Ничего не делаем
                                        }
                                        else
                                            readedClient.Номер_квартиры = Convert.ToInt32(readedApartament);
                                        //______________________________________________
                                        readedClient.Телефон = readedPhone;
                                        //О Договоре
                                        readedContract.Номер_договора = readednumberContract;
                                        readedContract.Наименование_товара = readednameProduct;
                                        readedContract.Виды_товаров = Category.SelectedItem as Виды_товаров;
                                        readedContract.Срок_хранения = Period.SelectedItem as Срок_хранения;
                                        readedContract.Дата_сдачи = readed_dataOfDilivery;
                                        readedContract.Дата_погашения = readedMaturityDate;
                                        readedContract.Статус_договора = readedstatus;
                                        readedContract.Оценка_товара = Convert.ToDecimal(readedProductEvolation);
                                        readedContract.Сумма_займа = Convert.ToDecimal(readedSummCount);
                                        //Проверка необзательных полей договора
                                        //_____________________________________________
                                        if (Category.SelectedIndex == 11)
                                        {
                                            if (Metal.Text.Trim() != null && Metal.Text.Trim() != "")
                                            {
                                                readedContract.Металл = readedmetal;
                                            }
                                            if (Weight.Text.Trim() != null && Weight.Text.Trim() != "")
                                            {
                                                readedContract.Вес = Convert.ToDouble(readedWeight);
                                            }
                                        }
                                        if (AmountPayment.Text.Trim() == null || AmountPayment.Text.Trim() == "" || AmountPayment.Text == "Не указано")
                                        {
                                            //Ничего не делаем
                                        }
                                        else
                                            readedContract.Сумма_выплаты = Convert.ToDecimal(readedAmountPayment);
                                        //______________________________________________
                                        en.SaveChanges();
                                        MessageBox.Show("Данные о договоре изменены", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                                    }
                                    else
                                        MessageBox.Show("Сумма займа должна быть меньше оценки товара!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                            }
                            else
                                MessageBox.Show("Серия и номер паспорта должны состовлять 10 цифр\n Введите корректное значение!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                        else
                            MessageBox.Show("Номер договора должен состовлять 10 символов\n Введите корректное значение!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                }
                int id_zapis = ListContract.SelectedIndex;
                ListContract.Items.Clear();
                foreach (var x in en.Договоры)
                {
                    if (DateTime.Now < x.Дата_погашения)
                    {
                        ListContract.Items.Add(x);
                    }
                }
                ListContract.SelectedIndex = id_zapis;
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var x in en.Договоры)
            {
                if (DateTime.Now <x.Дата_погашения )
                {
                    ListContract.Items.Add(x);
                }
            }
            foreach (Виды_товаров x in en.Виды_товаров)
            {
                Category.Items.Add(x);
            }
            foreach(var x in en.Срок_хранения)
            {
                Period.Items.Add(x);
            }
        }

        private void Category_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Category.SelectedIndex != -1)
            {
                var minprice = Category.SelectedItem as Виды_товаров;
                if (ProductEvolation.Text == "")
                {
                    ProductEvolation.Text = Convert.ToInt32(minprice.МинЦена).ToString();
                }
                else
                {
                    int readedPrice = Convert.ToInt32(ProductEvolation.Text);
                    if (readedPrice < minprice.МинЦена)//Проверка на минимальную цену категории товара
                    {
                        ProductEvolation.Text = Convert.ToInt32(minprice.МинЦена).ToString();
                    }
                }
                
            }
            if(Category.SelectedIndex==11)
            {
                LMetal.Visibility = Visibility.Visible;
                Metal.Visibility = Visibility.Visible;
                LWeight.Visibility = Visibility.Visible;
                Weight.Visibility = Visibility.Visible;
            }
            else
            {
                LMetal.Visibility = Visibility.Hidden;
                Metal.Visibility = Visibility.Hidden;
                LWeight.Visibility = Visibility.Hidden;
                Weight.Visibility = Visibility.Hidden;
            }
        }

        private void ListContract_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(ListContract.SelectedItem is Договоры selected_contract)
            {
                RWork.Visibility = Visibility.Visible;//Включаем кнопку переоформить
                //Подставление значение по договору
                NumberContract.Text = selected_contract.Номер_договора.Trim();
                NameProduct.Text = selected_contract.Наименование_товара.Trim();
                Category.SelectedItem = (from id in en.Виды_товаров where id.Код_вида == selected_contract.Виды_товаров.Код_вида select id).Single<Виды_товаров>();
                if (Category.SelectedIndex == 11)
                {
                    if (selected_contract.Металл.Trim() != null)
                        Metal.Text = selected_contract.Металл.Trim();
                    if (selected_contract.Вес != null)
                        Weight.Text = selected_contract.Вес.ToString();
                }
                Period.SelectedItem = (from id in en.Срок_хранения where id.Код_срока == selected_contract.Срок_хранения.Код_срока select id).Single<Срок_хранения>();
                DateofDilivery.SelectedDate = selected_contract.Дата_сдачи;
                MaturityDate.SelectedDate = selected_contract.Дата_погашения;
                Status.IsChecked = selected_contract.Статус_договора;
                if (Status.IsChecked == true)//Отображение статуса,что договор закрыт
                {
                    StatusText.Foreground = Brushes.Red; 
                    StatusText.Content = "Закрыт";
                }
                if(Status.IsChecked ==false)//Отображение статуса,что договор открыт
                {
                    StatusText.Foreground = Brushes.Green;
                    StatusText.Content = "Открыт";
                }
                ProductEvolation.Text = Convert.ToInt32(selected_contract.Оценка_товара).ToString();
                SummCount.Text = Convert.ToInt32(selected_contract.Сумма_займа).ToString();
                //Проверка на пустое поле сумма выплаты
                if (selected_contract.Сумма_выплаты == null || selected_contract.Сумма_выплаты == 0)
                    AmountPayment.Text = "Не указано";
                else
                    AmountPayment.Text = Convert.ToInt32(selected_contract.Сумма_выплаты).ToString();
                int Day =(DateTime.Today- DateofDilivery.SelectedDate.Value).Days;//Кол-во дней
                var selected_percent=Period.SelectedItem as Срок_хранения;
                double Percent = selected_percent.Процент;//Берём процентную ставку
                if (Day > 0)
                    SummAmount.Content = (Convert.ToInt32((Percent * Day * Convert.ToInt32(selected_contract.Сумма_займа / 100)) + 
                        Convert.ToInt32(selected_contract.Сумма_займа))).ToString()+ "₽";//Просчёт процентов от количества дней
                else
                    SummAmount.Content = "";
                foreach (var x in en.Сотрудники)//Подставляем ФИО Сотрудника из БД
                {
                    if(selected_contract.Сотрудники.Код_сотрудника==x.Код_сотрудника)
                    {
                        if (x.Отчество == null)
                            Worker.Text = x.Фамилия.Trim() + " " + x.Имя.Trim();
                        else
                            Worker.Text = x.Фамилия.Trim() + " " + x.Имя.Substring(0, 1) + ". " + x.Отчество.Substring(0, 1) + ".";
                    }
                }
                //Подставление значение по Клиенту
                Name.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Имя.Trim();
                LastName.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Фамилия.Trim();
                //Проверка на пустое поле Фамилии
                if (selected_contract.Клиенты.Отчество==null||selected_contract.Клиенты.Отчество=="")
                    SecondName.Text = "Не указано";//Если поле пустое
                else
                    SecondName.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Отчество.Trim();//Если оно заполнено
                Number.Text= (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Серия_номер.Trim();
                DateOFissue.SelectedDate= (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Дата_выдачи;
                Country.Text= (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Страна.Trim();
                Region.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Регион.Trim();
                City.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Населённый_пункт.Trim();
                Street.Text= (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Улица.Trim();
                Home.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Номер_дома.ToString();
                //Проверка на пустое поле номера квартиры
                if (((from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Номер_квартиры == null))
                        Apartament.Text = "Не указано";//Если поле пустое
                else
                    Apartament.Text= (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Номер_квартиры.ToString();//Если поле заполнено
                Phone.Text = (from id in en.Клиенты where id.Код_Клиента == selected_contract.Клиенты.Код_Клиента select id).Single<Клиенты>().Телефон.Trim();
            }
        }

        private void Delete_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if(ListContract.SelectedItem is Договоры delete_contract)
            {
                MessageBoxResult result = MessageBox.Show("Вы действительно хотите удалить договор?",
                    "Обновление",MessageBoxButton.YesNo,MessageBoxImage.Question);
                if (MessageBoxResult.Yes == result)
                {
                    int id_delete_contract = 0;
                    foreach (var x in en.Клиенты)
                        if (x.Код_Клиента == delete_contract.Клиенты.Код_Клиента)
                        {
                            en.Клиенты.Remove(x);
                            break;
                        }
                    foreach (var x in en.Договоры)
                        if (x.Номер == delete_contract.Номер)
                        {
                            id_delete_contract = x.Номер;
                            en.Договоры.Remove(x);
                            break;
                        }
                    en.SaveChanges();
                    ListContract.SelectedIndex = -1;
                    /*Информация о договоре
    ________________________________*/
                    NumberContract.Clear();
                    NameProduct.Clear();
                    Category.SelectedIndex = -1;
                    Period.SelectedIndex = -1;
                    DateofDilivery.SelectedDate = null;
                    MaturityDate.SelectedDate = null;
                    Status.IsChecked = false;
                    ProductEvolation.Clear();
                    SummCount.Clear();
                    AmountPayment.Clear();
                    StatusText.Content = "";
                    Metal.Clear();
                    Weight.Clear();
                    //___________________________

                    /*Информация о клиенте
                     __________________________*/
                    Name.Clear();
                    LastName.Clear();
                    SecondName.Clear();
                    Number.Clear();
                    DateOFissue.SelectedDate = null;
                    Country.Clear();
                    Region.Clear();
                    City.Clear();
                    Street.Clear();
                    Home.Clear();
                    Apartament.Clear();
                    Phone.Clear();
                    ListContract.Items.Clear();
                    RWork.Visibility = Visibility.Hidden;
                    foreach (var x in en.Договоры)
                    {
                        if (DateTime.Now < x.Дата_погашения)
                        {
                            ListContract.Items.Add(x);
                        }
                    }
                    MessageBox.Show("Договор удалён", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
                MessageBox.Show("Нет удаляемых объектов", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        private void Apartament_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Apartament.Text == "Не указано")
                Apartament.Text = "";
        }

        private void SecondName_GotFocus(object sender, RoutedEventArgs e)
        {
            if (SecondName.Text == "Не указано")
                SecondName.Text = "";
        }

        private void DateofDilivery_CalendarClosed(object sender, RoutedEventArgs e)
        {
            if (DateofDilivery.SelectedDate.HasValue == true)
            {
                if (Period.SelectedIndex == -1)
                {
                    MessageBox.Show("Выберите срок хранения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    DateofDilivery.SelectedDate = null;
                }
                else
                {
                    double days = 0;
                    foreach (var x in en.Срок_хранения)
                    {
                        if ((Period.SelectedItem as Срок_хранения).Количество_дней == x.Количество_дней)
                            days = Convert.ToDouble(x.Количество_дней);
                    }
                    DateTime Dilevery = DateofDilivery.SelectedDate.Value;
                    DateTime Matiturity = Dilevery.AddDays(days);
                    MaturityDate.SelectedDate = Matiturity;//Подсчёт даты погашения 
                }
            }
        }
        private void Period_DropDownClosed(object sender, EventArgs e)
        {
            if (DateofDilivery.SelectedDate.HasValue == true)
            {
                double days = 0;
                foreach (var x in en.Срок_хранения)
                {
                    if ((Period.SelectedItem as Срок_хранения).Количество_дней == x.Количество_дней)
                        days = Convert.ToDouble(x.Количество_дней);
                }
                DateTime Dilevery = DateofDilivery.SelectedDate.Value;
                DateTime Matiturity = Dilevery.AddDays(days);
                MaturityDate.SelectedDate = Matiturity;//Подсчёт даты погашения
            }
        }

        private void AmountPayment_GotFocus(object sender, RoutedEventArgs e)
        {
            if (AmountPayment.Text == "Не указано")
                AmountPayment.Text = "";
        }


        private void SummCount_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void AmountPayment_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }
        private void Home_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Apartament_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Phone_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Number_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Search_KeyDown(object sender, KeyEventArgs e)
        {
                if (Tsearch.Text.Trim() != ""&&Tsearch.Text!="Введите номер договора для поиска")
                {
                    foreach (var item in en.Договоры)
                    {
                        if (item.Номер_договора.Contains((Tsearch.Text.Trim())) && DateTime.Now < item.Дата_погашения)
                        {
                            ListContract.Items.Clear();
                            ListContract.Items.Add(item);
                            break;
                        }
                    }
                }
        }

        private void Tsearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Обновляем список при пустом поле поиска
            if (Tsearch.Text == "" )
            {
                ListContract.Items.Clear();
                foreach (var x in en.Договоры)
                {
                    if(DateTime.Now < x.Дата_погашения)
                        ListContract.Items.Add(x);
                }     
            }
        }

        private void ProductEvolation_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void RWork_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы действительно хотите переоформить договор?", 
                "Обновление", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (MessageBoxResult.Yes == result)
            {
                var readedContract = ListContract.SelectedItem as Договоры;
                //Переписываем всё в переменные
                Сотрудники readedidWorker = new Сотрудники();
                foreach (var x in en.Сотрудники)
                {
                    if (x.Код_сотрудника == save_idworker.idworker)
                        readedidWorker = x;
                }
                readedContract.Сотрудники = readedidWorker;//Присваиваем код сотрудника
                en.SaveChanges();
                int id_zapis = ListContract.SelectedIndex;//Записываем выбранный индекс элемента в списке
                                                          //Обновляем список договоров
                ListContract.Items.Clear();
                foreach (var x in en.Договоры)
                {
                    if (DateTime.Now < x.Дата_погашения)
                    {
                        ListContract.Items.Add(x);
                    }
                }
                ListContract.SelectedIndex = id_zapis;//Возвращаем выбранный индекс элемента в списке
                MessageBox.Show("Договор переоформлен", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Weight_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Weight.Text == "Не указано")
                Weight.Text = "";
        }

        private void Metal_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Metal.Text == "Не указано")
                Metal.Text = "";
        }
        private void Period_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Period.SelectedIndex > -1)
            {
                var selected_Period = Period.SelectedItem as Срок_хранения;
                Percent.Content = selected_Period.Процент.ToString() + "%";
            }
        }

        private void Weight_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9,Key.OemComma};

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Tsearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if(Tsearch.Text== "Введите номер договора для поиска")
            {
                Tsearch.Text = "";
            }
        }
    }
}
