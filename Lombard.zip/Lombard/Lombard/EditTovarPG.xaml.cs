﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lombard
{
    public partial class EditTovarPG : Page
    {
        Entities s = new Entities();
        private Товары _currentTovar = new Товары();
        public EditTovarPG(Товары selected_tovar)
        {
            if (selected_tovar != null)
                _currentTovar = selected_tovar;
            InitializeComponent();
            DataContext = _currentTovar;
        }
        public static int id { get; set; }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var x in s.Виды_товаров)
            {
                Category.Items.Add(x);
            }
            string Number_Contract= Number.Text;
            Договоры edit_tovar = null;
            foreach (var x in s.Договоры)
            {
                if(Number_Contract==x.Номер_договора.Trim())
                {
                    edit_tovar = x;
                    id = x.Номер;
                    break;
                }
            }
            Category.SelectedItem = edit_tovar.Виды_товаров as Виды_товаров;
            if (edit_tovar.Статус_договора == true)
                Status.SelectedIndex = 1;
            else
                Status.SelectedIndex = 0;
            if(edit_tovar.Металл==null)
            {
                Jewerly.Visibility = Visibility.Hidden;
                NotJewerly.Margin = new Thickness(32, 110, 0, 0);
            }
            else
            {
                Material.Text = edit_tovar.Металл.Trim();
                Weight.Text = (edit_tovar.Вес).ToString();
                NotJewerly.Margin = new Thickness(33, 183, 0, 0);
                Jewerly.Visibility = Visibility.Visible;
            }
        }
        private void Load()
        {
            Договоры load_tovar = null;//Переменная для подгрузки данных товара в поля
            foreach (var x in s.Договоры)
            {
                if (id == x.Номер)
                {
                    load_tovar = x;
                    break;
                }
            }
            Name.Text = load_tovar.Наименование_товара.Trim();
            Number.Text = load_tovar.Номер_договора;
            Category.SelectedItem = load_tovar.Виды_товаров as Виды_товаров;
            if(load_tovar.Металл!=null)
            {
                Material.Text = load_tovar.Металл;
                Weight.Text = load_tovar.Вес.ToString();
            }
            Price.Text = Convert.ToInt32(load_tovar.Оценка_товара).ToString();
            MinPrice.Text = Convert.ToInt32(load_tovar.Виды_товаров.МинЦена).ToString();
            if (load_tovar.Статус_договора == false)
                Status.SelectedIndex = 0;
            else
                Status.SelectedIndex = 1;
            if (load_tovar.Сотрудники.Отчество == null)
                Worker.Text = load_tovar.Сотрудники.Фамилия.Trim() + " " + load_tovar.Сотрудники.Имя.Trim();
            else
                Worker.Text = load_tovar.Сотрудники.Фамилия.Trim() + " " + load_tovar.Сотрудники.Имя.Substring(0, 1) + 
                    ". " + load_tovar.Сотрудники.Отчество.Substring(0, 1) + ".";
        }

        private void Rwork_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы действительно хотите переоформить товар?"
                , "Обновление", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (MessageBoxResult.Yes == result)
            {
                string Number_Contract = Number.Text;//Переменная для поиска товара
                Договоры edit_tovar = null;
                Сотрудники idworker = null;
                foreach (var x in s.Сотрудники)//Поиск авторизированного сотрудника
                {
                    if (x.Код_сотрудника == save_idworker.idworker)
                    {
                        idworker = x;
                        break;
                    }
                }
                foreach (var x in s.Договоры)
                {
                    if (Number_Contract == x.Номер_договора.Trim())
                    {
                        edit_tovar = x;
                        break;
                    }
                }
                if(idworker==edit_tovar.Сотрудники)
                    MessageBox.Show("Договор уже оформлен на вас", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                else
                {
                    edit_tovar.Сотрудники = idworker;
                    s.SaveChanges();
                    MessageBox.Show("Товар переоформлен", "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                    Load();
                }
            }  
        }

        private void Price_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9 };

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Weight_KeyDown(object sender, KeyEventArgs e)
        {
            //Ограничение на ввод только чисел
            var allowed = new[] { Key.D0, Key.D1, Key.D2, Key.D3, Key.D4, Key.D5, Key.D6,
Key.D7, Key.D8, Key.D9, Key.NumPad0, Key.NumPad1, Key.NumPad2, Key.NumPad3, Key.NumPad4,
Key.NumPad5, Key.NumPad6, Key.NumPad7, Key.NumPad8, Key.NumPad9,Key.OemComma};

            if (allowed.Contains(e.Key))
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void Save_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
                string Number_Contract = Number.Text;
                Договоры edit_tovar = null;
                foreach (var x in s.Договоры)
                {
                    if (Number_Contract == x.Номер_договора.Trim())
                    {
                        edit_tovar = x;
                        break;
                    }
                }
                if (Name.Text == "" || Category.SelectedIndex == -1 || Price.Text == "" 
                || Status.SelectedIndex == -1)//Проверка на заполненность всех полей
                {
                    MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                MessageBoxResult result = MessageBox.Show("Вы действительно хотите изменит данные товара?", 
                    "Обновление", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (MessageBoxResult.Yes == result)
                {
                    if (Material.Text== null)//Если не ювелирное украшение
                    {
                        int readedPrice = Convert.ToInt32(Price.Text);
                        var minprice = Category.SelectedItem as Виды_товаров;
                        if (readedPrice < minprice.МинЦена)//Проверка на минимальную цену категории товара
                        {
                            MessageBox.Show("Цена товара не должна быть ниже минимальной", 
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            Price.Text = Convert.ToInt32(minprice.МинЦена).ToString();
                        }
                        else
                        {
                            id = edit_tovar.Номер;
                            edit_tovar.Наименование_товара = Name.Text.Trim();
                            edit_tovar.Виды_товаров = Category.SelectedItem as Виды_товаров;
                            edit_tovar.Оценка_товара = Convert.ToDecimal(Price.Text);
                            if (Status.SelectedIndex == 0)
                            {
                                edit_tovar.Статус_договора = false;
                                edit_tovar.Дата_продажи = null;
                            }
                            else
                            {
                                edit_tovar.Статус_договора = true;
                                edit_tovar.Дата_продажи = DateTime.Now;
                            }
                            s.SaveChanges();
                            Load();
                            MessageBox.Show("Данные товара изменены", 
                                "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    else//Если ювелирное украшение
                    {
                        int readedPrice = Convert.ToInt32(Price.Text);
                        var minprice = Category.SelectedItem as Виды_товаров;
                        if (readedPrice < minprice.МинЦена)//Проверка на минимальную цену категории товара
                        {
                            MessageBox.Show("Цена товара не должна быть ниже минимальной", 
                                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            Price.Text = Convert.ToInt32(minprice.МинЦена).ToString();
                        }
                        else
                        {
                            id = edit_tovar.Номер;
                            edit_tovar.Наименование_товара = Name.Text.Trim();
                            edit_tovar.Виды_товаров = Category.SelectedItem as Виды_товаров;
                            edit_tovar.Металл = Material.Text;
                            edit_tovar.Вес = Convert.ToDouble(Weight.Text);
                            edit_tovar.Оценка_товара = Convert.ToDecimal(Price.Text);
                            if (Status.SelectedIndex == 0)
                            {
                                edit_tovar.Статус_договора = false;
                                edit_tovar.Дата_продажи = null;
                            }
                            else
                            {
                                edit_tovar.Статус_договора = true;
                                edit_tovar.Дата_продажи = DateTime.Now;
                            }
                            s.SaveChanges();
                            Load();
                            MessageBox.Show("Данные товара изменены", 
                                "Обновление", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                }
            }
        }

        private void Back_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FR.MainFrame.Navigate(new TovarsPage());
        }

        private void Category_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Category.SelectedIndex != -1)
            {
                var minprice = Category.SelectedItem as Виды_товаров;
                MinPrice.Text = Convert.ToInt32(minprice.МинЦена).ToString();
            }
            if (Category.SelectedIndex == 11)
            {
                NotJewerly.Margin = new Thickness(33, 183, 0, 0);
                Jewerly.Visibility = Visibility.Visible;
            }
            else
            {
                Material.Text = null;
                Weight.Text = null;//Очищаем поля
                NotJewerly.Margin = new Thickness(32, 110, 0, 0);
                Jewerly.Visibility = Visibility.Hidden;
            }
        }
    }
}
